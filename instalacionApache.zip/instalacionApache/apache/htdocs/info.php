<?
phpinfo();
?>

	
